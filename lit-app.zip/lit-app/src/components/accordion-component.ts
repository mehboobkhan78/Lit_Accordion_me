import { LitElement, html, css } from 'lit';

export class AccordionComponent extends LitElement {
  static properties = {
    openIndex: { type: Number }
  };

  openIndex: number | null = null;

  constructor() {
    super();
    this.openIndex = null;
  }

  static styles = css`
    .accordion {
      width: 100%;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .item {
      border-bottom: 1px solid #ddd;
    }

    .header {
      background: #f0f0f0;
      padding: 10px;
      cursor: pointer;
      font-weight: bold;
    }

    .content {
      padding: 10px;
      display: none;
    }

    .content.open {
      display: block;
    }
  `;

  toggle(index:number) {
    this.openIndex = this.openIndex === index ? null : index;
  }

  render() {
    return html`
      <div class="accordion">
        ${['Section 1', 'Section 2', 'Section 3'].map((title, index) => html`
          <div class="item">
            <div class="header" @click="${() => this.toggle(index)}">${title}</div>
            <div class="content ${this.openIndex === index ? 'open' : ''}">
              <p>This is the content for ${title}</p>
            </div>
          </div>
        `)}
      </div>
    `;
  }
}

customElements.define('accordion-component', AccordionComponent);
