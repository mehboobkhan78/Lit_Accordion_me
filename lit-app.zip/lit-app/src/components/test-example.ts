import { LitElement, html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import './example-element.js'; // Import the ExampleComponent

@customElement('test-example')
class TestExample extends LitElement {
  @property({ type: String }) name = 'World';

  static styles = css`
    :host {
      display: block;
      padding: 16px;
      color: var(--test-example-text-color, black);
    }
  `;

  render() {
    return html`
    <div>
     <example-component></example-component>
    </div>
    `;
  }
}

customElements.define('test-example', TestExample);