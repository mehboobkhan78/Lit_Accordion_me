import { LitElement, html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { theme } from '../styles/theme';

@customElement('example-element')
export class ExampleComponent extends LitElement {
  static styles = [
    css`
      :host {
        display: block;
        color: var(--color-primary);
      }
    `
  ];

  @property() heading = 'Registration Form';
  @property() mobileNumber = '9811150856';
  @property() email = 'john.doe@example.com';

  render() {
    return html`<h1>Hello, ${this.heading}</h1>
    <p>Welcome to the example component!</p>
    <table border="1" cellpadding="5" cellspacing="0" style="width: 50px; background-color: var(--color-surface);">
      <tr>
        <td>Mobile Number:</td>
        <td><input type="text" value="${this.mobileNumber}" /></td>
      </tr>
      <tr>
        <td>Address:</td>
        <td><input type="text" value="123 Main St, Anytown, USA" /></td>
      </tr>
      <tr>
        <td>Email:</td>
        <td><input type="text" value="${this.email}" /></td>
      </tr>
      <tr>
        <td colspan="2"><input type="submit" value="Submit"></td>
      </tr>
      </table>
    `;
  }
}
