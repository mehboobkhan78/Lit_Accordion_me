import { LitElement, html, css } from 'lit';

export class AccordionCheckbox extends LitElement {
  static styles = css`
    details {
      border: 1px solid #ccc;
      border-radius: 4px;
      padding: 10px;
      width: 250px;
      font-family: Arial, sans-serif;
    }

    summary {
      font-weight: bold;
      cursor: pointer;
      padding: 5px;
    }

    .checkbox-group {
      padding: 10px 0 0 10px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
  `;

  render() {
    return html`
      <details>
        <summary>Select Options</summary>
        <div class="checkbox-group">
          <label><input type="checkbox" /> Option 1</label>
          <label><input type="checkbox" /> Option 2</label>
          <label><input type="checkbox" /> Option 3</label>
        </div>
      </details>
    `;
  }
}

customElements.define('accordion-checkbox', AccordionCheckbox);
